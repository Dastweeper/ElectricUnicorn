Autotest.add_discovery { "rails" }
Autotest.add_discovery { "rspec2" }
